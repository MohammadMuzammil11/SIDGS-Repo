 var proccode=context.getVariable("middlewareRequest.procCode");
 var backendurl =context.getVariable('middlewareRequest.backend.url');
 
 if (proccode == "EV0000"){
     
     backendurl=backendurl+"/itd"
 }
 if (proccode == "D10000"){
      backendurl=backendurl+"/cdm1/deposit"
 }
  if (proccode == "PA0000"){
    backendurl=backendurl+"/cdm1/validate" 
 }
 context.setVariable('target.url', backendurl);