  /**
 * @ProcCodeToBackendConfiguration
 **/
var procCode = context.getVariable("ProcCode");
var ProcCodeToBackendFlag = false;
ProcCodeToBackendFlag = context.getVariable('propertyset.ProcCode_Backend_Config.ProcCodeToBackendFlag');

try {

    print("Flag" + ProcCodeToBackendFlag)

    if (ProcCodeToBackendFlag === false) {
        print("in if for flag")
        throw err;
    }
    else {
        var backendInfo = context.getVariable('propertyset.ProcCode_Backend_Config.' + procCode);
        if (backendInfo !== null) {
            var backendInfo_list = backendInfo.split(",");
            var backendCode = backendInfo_list[0];
            var procCodeActiveFlag = backendInfo_list[1];
            if (backendCode === "" || procCodeActiveFlag === "") {
                print("BackendCode: ",backendCode);
                print("ProcCode Flag Status: ",procCodeActiveFlag);
                throw "961_FailedToRetriveProcCodetoBackendInfo";
            } else {
                if (procCodeActiveFlag != "Active" || procCodeActiveFlag == "InActive") {
                    throw "961_ProcCodeStatusIsInActive";
                }
                else {
                    context.setVariable("middlewareRequest.backend.code", backendCode);
                }
            }
        } else {
            throw "961_FailedToRetriveProcCodetoBackendInfo";
        }
    }
}
catch (err) {
    throw err;
}