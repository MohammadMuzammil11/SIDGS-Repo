 var payload=context.getVariable("request.content");
payload=payload.toString();
print(payload);
payload=payload.replace(/</g,"&lt;");
print(payload);
payload='<ProcessMessage 	xmlns="http://CTL.COM/ONLINE/WebServices/ICICI/EAI"><requestMessage>'+payload+'</requestMessage></ProcessMessage>'
context.setVariable("request.content",payload);
 try{
    var request = payload;
        request = request.replace(/<\?xml.+\?>/g, '');
		request = request.replace(/\\/g, '\\\\');
		request = request.replace(/"/g, '\\"');
		request = request.replace(/\r?\n|\r/g, '');
		request = request.replace(/\s{2,}/g,'');
		request = request.replace(/\t/g,'');
 		request = request.replace(/\/XML>/gi, "\/XML>\\n");
		context.setVariable('request.content', request);
}
catch(err){
    print(err);
}
