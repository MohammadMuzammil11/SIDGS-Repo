   var bitmap = context.getVariable("private.IsoBitMapEV0000");
context.setVariable('iso-bitmap', bitmap);