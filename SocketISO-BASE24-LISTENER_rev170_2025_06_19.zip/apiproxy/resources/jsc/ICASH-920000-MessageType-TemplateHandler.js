/* 
* 920000 contains Three types request: 1200, 1420, 1421
* Accordingly we need to pick requestTemplate based on MessageType
*/

try{
    var procCode = context.getVariable("middlewareRequest.procCode");
    var messageType = context.getVariable("middlewareRequest.messageType");
    
    switch(messageType){
        case "1200":
            custProcCode = procCode+"-"+messageType;
			break;
		case "1420":
			custProcCode = procCode+"-"+messageType;
			break;
		case "1421":
			custProcCode = procCode+"-"+messageType;
			break;	
    }
    context.setVariable("middlewareRequest.procCode", custProcCode);
    context.setVariable("defaultProcCode", procCode);
}catch(err){
    throw err;
}