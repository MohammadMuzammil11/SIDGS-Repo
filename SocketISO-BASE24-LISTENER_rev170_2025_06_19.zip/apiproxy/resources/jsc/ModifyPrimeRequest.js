var payload=context.getVariable("request.content");
payload=payload.toString();

payload=payload.replace(/</g,"&lt;");
payload='<ProcessMessage  xmlns="http://CTL.COM/ONLINE/WebServices/ICICI/EAI"><requestMessage>'+payload+'</requestMessage></ProcessMessage>';

context.setVariable("request.content",payload);
