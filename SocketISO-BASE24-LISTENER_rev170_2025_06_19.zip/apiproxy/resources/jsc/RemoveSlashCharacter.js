 /*
 * @Linearize XML payload
 */
 try{
    var request = context.getVariable("request.content");
        request = request.replace(/<\?xml.+\?>/g, '');
		request = request.replace(/\\/g, '\\\\');
		request = request.replace(/"/g, '\\"');
		request = request.replace(/\r?\n|\r/g, '');
		request = request.replace(/\s{2,}/g,'');
		request = request.replace(/\t/g,'');
 		request = request.replace(/\/XML>/gi, "\/XML>\\n");
 		request = request.replace(/\|/g, '');
		context.setVariable('request.content', request);
}
catch(err){
    print(err);
}
	var TranType = context.getVariable("middlewareRequest.NCMC.TranType");
	var DebitFlag = context.getVariable("middlewareRequest.NCMC.DebitFlag");
	var AddInfo = context.getVariable("middlewareRequest.NCMC.AddPvt125Data-AddInfo");
	var SrvId = context.getVariable("middlewareRequest.NCMC.AddPvt125Data-SrvId");
	var SrvMgmInfo = context.getVariable("middlewareRequest.NCMC.AddPvt125Data-SrvMgmInfo");
		
	if (TranType !== null){
	context.setVariable("middlewareRequest.NCMC.TranType", context.getVariable("middlewareRequest.NCMC.TranType").replace(/\|/g, ''));
	} if (DebitFlag !== null){
	context.setVariable("middlewareRequest.NCMC.DebitFlag", context.getVariable("middlewareRequest.NCMC.DebitFlag").replace(/\|/g, ''));
	} if (AddInfo !== null){
	context.setVariable("middlewareRequest.NCMC.AddPvt125Data-AddInfo", context.getVariable("middlewareRequest.NCMC.AddPvt125Data-AddInfo").replace(/\|/g, ''));
	} if (SrvId !== null){
	context.setVariable("middlewareRequest.NCMC.AddPvt125Data-SrvId", context.getVariable("middlewareRequest.NCMC.AddPvt125Data-SrvId").replace(/\|/g, ''));
	} if (SrvMgmInfo !== null){
	context.setVariable("middlewareRequest.NCMC.AddPvt125Data-SrvMgmInfo", context.getVariable("middlewareRequest.NCMC.AddPvt125Data-SrvMgmInfo").replace(/\|/g, ''));
	}