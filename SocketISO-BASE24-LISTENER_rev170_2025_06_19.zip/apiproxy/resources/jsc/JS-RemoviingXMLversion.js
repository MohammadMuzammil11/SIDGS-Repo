 var response = context.getVariable("response.content");

 try{
     response = response.replace('<?xml version="1.0" encoding="UTF-8"?>', '');

}
catch(err){
    print(err);
}

context.setVariable("response.content",response);