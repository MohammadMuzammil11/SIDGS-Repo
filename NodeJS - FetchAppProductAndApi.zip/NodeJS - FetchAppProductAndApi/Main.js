const axios = require('axios');
const { createObjectCsvWriter } = require('csv-writer');
var allApps = [];
let apigeeXManagementHost = "apigee.googleapis.com";
let orgName = "bdo-unibank-prd-x-int";
let accessToken = "ya29.a0AcM612zZbZh4ogQ9z5U4DHutdvSQH5NaExh60W8j0_9gMKXrKIcFgAet4K6zNo7y1KX-ZT4dK9I7NDF7yhULijpb2Zns6v3rz2kIb3sBBt7HWX-fBC6WiBCx4ODNMxYUUVpHmrHye1cBdT7NjUTGyEbtg7dsaZQLb3N8qzuGJcvYlzO0Cj-qdw3H5ehSHg2J2i5UaHOfidQ_fbS77MKZIlu8x7RJuw8m4AUx28z5OU-WZTPOKOS9CXPJ3bNweR5AttMOM8gwVumJ3YapeqHJIfsBYgC_6gDIPlm7wU6fz0Rle5ELjIckMh_DiRj92mly8l2ijJ_3vMTuyByd5kKQKOpqfhrTs5s5oqHar814fsKAnzPUtJryn5AADpbUlzIvNmPN43mKzsajl5V1sx3vncWJrbiuWjy5aCgYKAXgSARESFQHGX2Mi5MWHRsKFkqsqewFZwZf-Ng0423";

// Function to get the apps List
async function getAppsList() {
    const url = `https://${apigeeXManagementHost}/v1/organizations/${orgName}/apps`;
    const headers = { 'Authorization': `Bearer ${accessToken}` };
    const response = await axios.get(url, { headers });
    return response.data || [];
}

async function getAppProfileForId(appId) {
    const url = `https://${apigeeXManagementHost}/v1/organizations/${orgName}/apps/${appId}`;
    const headers = { 'Authorization': `Bearer ${accessToken}` };
    const response = await axios.get(url, { headers });
    let apiproductCreds = null;
    if(response.data.credentials.length > 2)  apiproductCreds = response.data.credentials[0].apiProducts.concat(response.data.credentials[1].apiProducts,response.data.credentials[2].apiProducts);
    else if(response.data.credentials.length > 1) apiproductCreds = response.data.credentials[0].apiProducts.concat(response.data.credentials[1].apiProducts);
    else apiproductCreds = response.data.credentials[0].apiProducts;
    let appResp = {'appName': response.data.name, 'apiProductsOfFirstCreds' : apiproductCreds};
    return appResp;
}

async function getApiProductDetails(apiproduct) {
    const url = `https://${apigeeXManagementHost}/v1/organizations/${orgName}/apiproducts/${apiproduct}`;
    const headers = { 'Authorization': `Bearer ${accessToken}` };
    const response = await axios.get(url, { headers });
    return response.data.operationGroup.operationConfigs;
}

// Write the collected data to a CSV file
async function saveToCsv(data, filename = `${orgName} - apps_info.csv`) {
    const csvWriter = createObjectCsvWriter({
        path: filename,
        header: [
            { id: 'App Name', title: 'App Name' },
            { id: 'API Product', title: 'API Product' },
            { id: 'API Proxy', title: 'API Proxy' }
        ]
    });
    await csvWriter.writeRecords(data);
    console.log(`Data saved to ${filename}`);
}

// Main function to run the script
async function main() {
    try {
        const allAppIds = await getAppsList();
        for (const app of allAppIds.app) {
            const appDetails = await getAppProfileForId(app.appId);
            for (const apiProduct of appDetails.apiProductsOfFirstCreds){
                const apisInEachProduct = await getApiProductDetails(apiProduct.apiproduct);
                for (const apis of apisInEachProduct){
                    allApps.push({
                        'App Name': appDetails.appName,
                        'API Product': apiProduct.apiproduct,
                        'API Proxy' : apis.apiSource
                    });
                }
        }
        }
        await saveToCsv(allApps);
    } catch (error) {
        console.error('Error:', error);
    }
}
main()