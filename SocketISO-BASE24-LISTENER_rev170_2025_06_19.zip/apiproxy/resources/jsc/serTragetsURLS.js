 var  procCode = context.getVariable("middlewareRequest.procCode ");
 
 
  If(procCode ="777001")