var resp=context.getVariable("response.content");
resp=resp.replace(/&lt;/g,"<");
resp=resp.replace(/&gt;/g,">");
context.setVariable("response.content",resp);