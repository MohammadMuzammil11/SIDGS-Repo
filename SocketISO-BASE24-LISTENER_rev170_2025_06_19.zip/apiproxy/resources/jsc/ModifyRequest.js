var payload=context.getVariable("request.content");
payload=payload.toString();

payload=payload.replace(/</g,"&lt;");
print(payload);
payload='<ns0:AcceptPacketData  xmlns:ns0="http://newgen.com/"><ns0:EAI_InputXml>&lt;?xml version="1.0" encoding="UTF-8" standalone="no"?>'+payload+'</ns0:EAI_InputXml></ns0:AcceptPacketData>';

context.setVariable("request.content",payload);
